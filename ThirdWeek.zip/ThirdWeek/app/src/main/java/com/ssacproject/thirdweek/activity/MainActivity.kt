package com.ssacproject.thirdweek.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.Menu
import android.view.View
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager2.widget.ViewPager2
import com.ssacproject.thirdweek.*
import com.ssacproject.thirdweek.customadapter.CustomMainMenuAdAdapter
import com.ssacproject.thirdweek.customadapter.CustomTodaySaleAdapter
import com.ssacproject.thirdweek.customadapter.ItemTodaySale
import com.ssacproject.thirdweek.customview.CustomMainMenu
import com.ssacproject.thirdweek.customview.CustomMainMenuAd
import com.ssacproject.thirdweek.customview.CustomMainRecyclerView

class MainActivity : AppCompatActivity() {
    lateinit var toolbar: androidx.appcompat.widget.Toolbar
    lateinit var custom1: CustomMainRecyclerView
    lateinit var handler: Handler
    lateinit var handRun: Runnable
    lateinit var handler2: Handler
    lateinit var handRun2: Runnable
    lateinit var customMainMenuAd1: CustomMainMenuAd
    lateinit var customMainMenuAd2: CustomMainMenuAd
    lateinit var terms: LinearLayout
    lateinit var custom2: CustomMainRecyclerView
    lateinit var customMainMenu1: CustomMainMenu
    lateinit var customMainMenu2: CustomMainMenu
    lateinit var customMainMenu3: CustomMainMenu
    lateinit var customMainMenu4: CustomMainMenu
    lateinit var customMainMenu5: CustomMainMenu
    lateinit var customMainMenu6: CustomMainMenu
    lateinit var customMainMenu7: CustomMainMenu


    val frontAdList = listOf(
        R.drawable.ad1, R.drawable.ad2, R.drawable.ad3, R.drawable.ad4, R.drawable.ad5, R.drawable.ad6)
    val bottomAdList = listOf(R.drawable.bottom_ad1, R.drawable.bottom_ad2)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar!!.setDisplayShowTitleEnabled(false)

        customMainMenu1 = findViewById(R.id.customMainMenu1)
        customMainMenu1.setOnClickListener {
            val intent = Intent(this, RealMainActivity::class.java)
            intent.putExtra("position", 0)
            startActivity(intent)
        }
        customMainMenu2 = findViewById(R.id.customMainMenu2)
        customMainMenu2.setOnClickListener {
            val intent = Intent(this, RealMainActivity::class.java)
            intent.putExtra("position", 1)
            startActivity(intent)
        }
        customMainMenu3 = findViewById(R.id.customMainMenu3)
        customMainMenu3.setOnClickListener {
            val intent = Intent(this, RealMainActivity::class.java)
            intent.putExtra("position", 2)
            startActivity(intent)
        }
        customMainMenu4 = findViewById(R.id.customMainMenu4)
        customMainMenu4.setOnClickListener {
            val intent = Intent(this, RealMainActivity::class.java)
            intent.putExtra("position", 3)
            startActivity(intent)
        }
        customMainMenu5 = findViewById(R.id.customMainMenu5)
        customMainMenu5.setOnClickListener {
            val intent = Intent(this, RealMainActivity::class.java)
            intent.putExtra("position", 4)
            startActivity(intent)
        }
        customMainMenu6 = findViewById(R.id.customMainMenu6)
        customMainMenu6.setOnClickListener {
            val intent = Intent(this, RealMainActivity::class.java)
            intent.putExtra("position", 5)
            startActivity(intent)
        }
        customMainMenu7 = findViewById(R.id.customMainMenu7)
        customMainMenu7.setOnClickListener {
            val intent = Intent(this, RealMainActivity::class.java)
            intent.putExtra("position", 6)
            startActivity(intent)
        }

        // 커스텀 뷰페이저 설정
        customMainMenuAd1 = findViewById(R.id.customMainMenuAd1)
        val customAdAdapter1 = CustomMainMenuAdAdapter()
        customAdAdapter1.imageList = frontAdList
        customAdAdapter1.setShowAll = true
        customAdAdapter1.setOnItemClickListener(object: OnItemClickListener {
            override fun onItemClicked(view: View, pos: Int) {
                val intent = Intent(applicationContext, RealMainActivity::class.java)
                startActivity(intent)
            }
        })
        val len1 = customAdAdapter1.imageList.size
        customMainMenuAd1.tot.text = "${len1}"
        if (len1 > 0) {
            customMainMenuAd1.cur.text = "${1}"
        } else {
            customMainMenuAd1.cur.text = "${0}"
        }
        customMainMenuAd1.viewpager_ad.adapter = customAdAdapter1
        // 핸들러 설정해서 자동으로 스와이프
        handler = Handler()
        handRun = Runnable {
            customMainMenuAd1.viewpager_ad.currentItem = customMainMenuAd1.viewpager_ad.currentItem + 1
        }
        // 뷰페이저 스와이프할 때마다 숫자 바꿔주기
        customMainMenuAd1.viewpager_ad.registerOnPageChangeCallback(object: ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                handler.removeCallbacks(handRun)
                handler.postDelayed(handRun, 3000)
                customMainMenuAd1.tot.text = "${customAdAdapter1.imageList.size}"
                val now1 = position%customAdAdapter1.imageList.size + 1
                customMainMenuAd1.cur.text ="${now1}"
            }
        })

        custom1 = findViewById(R.id.custom1)
        val layoutManager1 = LinearLayoutManager(this)
        layoutManager1.orientation = LinearLayoutManager.HORIZONTAL
        custom1.recycler.layoutManager = layoutManager1
        val customAdapter1 = CustomTodaySaleAdapter(this)
        val data1 = ArrayList<ItemTodaySale>()
        data1.add(ItemTodaySale(R.drawable.logo_dominos, "도미노피자 전 메뉴", "7천원 할인", "기간:9/13~9/23", "", R.drawable.today_sale_food_domino, R.color.skyblue))
        data1.add(ItemTodaySale(R.drawable.logo_dominos, "도미노피자 전 메뉴", "7천원 할인", "기간:9/13~9/23", "", R.drawable.today_sale_food_domino, R.color.basy))
        data1.add(ItemTodaySale(R.drawable.logo_dominos, "도미노피자 전 메뉴", "7천원 할인", "기간:9/13~9/23", "", R.drawable.today_sale_food_domino, R.color.mint))
        data1.add(ItemTodaySale(R.drawable.logo_dominos, "도미노피자 전 메뉴", "7천원 할인", "기간:9/13~9/23", "", R.drawable.today_sale_food_domino, R.color.basy))
        customAdapter1.setItemClickListener(object: OnItemClickListener {
            override fun onItemClicked(view: View, pos: Int) {
                val intent = Intent(applicationContext, RealMainActivity::class.java)
                startActivity(intent)
            }
        })
        customAdapter1.todaySaleList = data1
        custom1.recycler.adapter = customAdapter1

        custom2 = findViewById(R.id.custom2)
        val layoutManager2 = LinearLayoutManager(this)
        layoutManager2.orientation = LinearLayoutManager.HORIZONTAL
        custom2.recycler.layoutManager = layoutManager2
        val customAdapter2 = CustomTodaySaleAdapter(this)
        val data2 = ArrayList<ItemTodaySale>()
        data2.add(ItemTodaySale(R.drawable.logo_dominos, "도미노피자 전 메뉴", "7천원 할인", "기간:9/13~9/23", "", R.drawable.today_sale_food_domino, R.color.basy))
        data2.add(ItemTodaySale(R.drawable.logo_dominos, "도미노피자 전 메뉴", "7천원 할인", "기간:9/13~9/23", "", R.drawable.today_sale_food_domino, R.color.mint))
        data2.add(ItemTodaySale(R.drawable.logo_dominos, "도미노피자 전 메뉴", "7천원 할인", "기간:9/13~9/23", "", R.drawable.today_sale_food_domino, R.color.skyblue))
        data2.add(ItemTodaySale(R.drawable.logo_dominos, "도미노피자 전 메뉴", "7천원 할인", "기간:9/13~9/23", "", R.drawable.today_sale_food_domino, R.color.basy))
        customAdapter2.setItemClickListener(object: OnItemClickListener {
            override fun onItemClicked(view: View, pos: Int) {
                val intent = Intent(applicationContext, RealMainActivity::class.java)
                startActivity(intent)
            }
        })
        customAdapter2.setItemLongClickListener(object: OnItemLongClickListener {
            override fun onItemLongClicked(view: View, pos: Int) {
                val item2 = customAdapter2.todaySaleList[pos]
                customAdapter2.todaySaleList.remove(item2)
                customAdapter2.notifyDataSetChanged()
            }
        })

        customAdapter2.todaySaleList = data2
        custom2.recycler.adapter = customAdapter2


        // 커스텀 뷰페이저 설정
        customMainMenuAd2 = findViewById(R.id.customMainMenuAd2)
        customMainMenuAd2.show_all.visibility = View.GONE
        val customAdAdapter2 = CustomMainMenuAdAdapter()
        customAdAdapter2.imageList = bottomAdList
        customAdAdapter2.setOnItemClickListener(object: OnItemClickListener {
            override fun onItemClicked(view: View, pos: Int) {
                val intent = Intent(applicationContext, RealMainActivity::class.java)
                startActivity(intent)
            }
        })
        val len2 = customAdAdapter2.imageList.size
        customMainMenuAd2.tot.text = "${len2}"
        if (len2 > 0) {
            customMainMenuAd2.cur.text = "${1}"
        } else {
            customMainMenuAd2.cur.text = "${0}"
        }
        customMainMenuAd2.viewpager_ad.adapter = customAdAdapter2
        // 핸들러 설정해서 자동으로 스와이프
        handler2 = Handler()
        handRun2 = Runnable {
            customMainMenuAd2.viewpager_ad.currentItem = customMainMenuAd2.viewpager_ad.currentItem + 1
        }
        // 뷰페이저 스와이프할 때마다 숫자 바꿔주기
        customMainMenuAd2.viewpager_ad.registerOnPageChangeCallback(object: ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                handler2.removeCallbacks(handRun2)
                handler2.postDelayed(handRun2, 3000)
                customMainMenuAd2.tot.text = "${len2}"
                val now2 = position%len2 + 1
                customMainMenuAd2.cur.text ="${now2}"
            }
        })

        terms = findViewById(R.id.terms)
        val showMoreTerm: ImageButton = terms.findViewById(R.id.showMoreTerm)
        val termsOfSurplusInfo: LinearLayout = terms.findViewById(R.id.termsOfSurplusInfo)
        showMoreTerm.setOnClickListener {
            if (termsOfSurplusInfo.visibility == View.VISIBLE) {
                termsOfSurplusInfo.visibility = View.GONE
                showMoreTerm.setImageResource(R.drawable.ic_baseline_expand_more_24)
            } else {
                termsOfSurplusInfo.visibility = View.VISIBLE
                showMoreTerm.setImageResource(R.drawable.ic_baseline_expand_less_24)
            }
        }


    }


    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(handRun)
        handler2.removeCallbacks(handRun2)
    }

    override fun onResume() {
        super.onResume()
        handler.postDelayed(handRun, 3000)
        handler2.postDelayed(handRun2, 3000)
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        getMenuInflater().inflate(R.menu.app_bar_menu, menu)
        return true
    }



}