package com.ssacproject.thirdweek.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.tabs.TabLayoutMediator
import com.ssacproject.thirdweek.R
import com.ssacproject.thirdweek.customadapter.ViewPagerFragmentAdapter
import com.ssacproject.thirdweek.databinding.ActivityRealMainBinding
import com.ssacproject.thirdweek.food_fragment_real.*
import kotlinx.coroutines.internal.artificialFrame

class RealMainActivity : AppCompatActivity() {
    lateinit var binding: ActivityRealMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRealMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var tabTitles = listOf<String>("배달", "배민1", "포장", "B마트", "쇼핑라이브",
                                        "선물하기", "전국별미")
        var fragmentList = listOf<Fragment>(
            FragmentDelivery(), FragmentBaminOne(),
            FragmentPackaging(), FragmentBMart(), FragmentShoppingLive(),
            FragmentPresent(), FragmentDomestic()
        )

        val adapter = ViewPagerFragmentAdapter(this)
        adapter.fragmentList = fragmentList
        binding.realMainViewpager.adapter = adapter
        binding.realMainViewpager.orientation = ViewPager2.ORIENTATION_HORIZONTAL
        TabLayoutMediator(binding.tabLayout, binding.realMainViewpager) { tab, position ->
            tab.text = tabTitles[position]
        }.attach()

        setSupportActionBar(binding.toolbar)
        val actionBar = supportActionBar
        // 뒤로가기 버튼 생성
        actionBar!!.setDisplayHomeAsUpEnabled(true)
        // 기본 타이틀 제거
        actionBar!!.setDisplayShowTitleEnabled(false)

        
        val pos = intent.getIntExtra("position", 0)
        binding.realMainViewpager.setCurrentItem(pos, false)
        binding.bottomnavi.setItemIconTintList(null)
        binding.bottomnavi.itemRippleColor = null

        val dialogView = layoutInflater.inflate(R.layout.bottom_sheet, null)
        val dialog = BottomSheetDialog(this)
        dialog.setContentView(dialogView)

        binding.toolbarTitle.setOnClickListener {
            dialog.show()

        }


    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            else -> return true
        }
        return super.onOptionsItemSelected(item)
    }

}