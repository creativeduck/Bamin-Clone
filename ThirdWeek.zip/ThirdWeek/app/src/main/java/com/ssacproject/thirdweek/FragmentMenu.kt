package com.ssacproject.thirdweek

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ssacproject.thirdweek.activity.SpecificActivity
import com.ssacproject.thirdweek.customadapter.SelectFoodItem
import com.ssacproject.thirdweek.customadapter.SelectMenuFoodItemAdapter

class FragmentMenu(val selectList: ArrayList<SelectFoodItem>) : Fragment() {
    lateinit var recyclerView: RecyclerView
    lateinit var adapter: SelectMenuFoodItemAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_menu, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView = view.findViewById(R.id.recyclerView)
        val layoutManager = LinearLayoutManager(context)
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        recyclerView.layoutManager = layoutManager
        adapter = SelectMenuFoodItemAdapter()
        adapter.selectList = selectList
        adapter.setOnItemClickListener(object: OnItemClickListener {
            override fun onItemClicked(view: View, pos: Int) {
                val intent = Intent(context, SpecificActivity::class.java)
                val title = view.findViewById<TextView>(R.id.select_menu_food_item_title).text.toString()
                intent.putExtra("title", title)
                startActivity(intent)
            }
        })
        recyclerView.adapter = adapter
    }


    // 유형에 따라 다르게 정렬하기
    fun changeDataSort(type: String) {
        when (type) {
            "chipTopRatings" -> {
                adapter.selectList.sortByDescending {
                    it.rating
                }
            }
            "chipTipLowest" -> {
                adapter.selectList.sortBy {
                    it.tip
                }
            }
            "chipFastest" -> {
                adapter.selectList.sortBy {
                    it.minTime
                }
            }
            else -> {
                adapter.selectList.sortBy {
                    it.title
                }
            }
        }
        adapter.notifyDataSetChanged()
    }

}