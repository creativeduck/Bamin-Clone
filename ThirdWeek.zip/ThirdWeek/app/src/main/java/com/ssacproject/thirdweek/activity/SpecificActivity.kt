package com.ssacproject.thirdweek.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.TextView
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayoutMediator
import com.ssacproject.thirdweek.FragmentMenu
import com.ssacproject.thirdweek.R
import com.ssacproject.thirdweek.customadapter.ViewPagerFragmentAdapter
import com.ssacproject.thirdweek.databinding.ActivitySpecificBinding
import com.ssacproject.thirdweek.food_fragment_real.FragmentBaminOne

class SpecificActivity : AppCompatActivity() {
    lateinit var binding: ActivitySpecificBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_specific)

        binding = ActivitySpecificBinding.inflate(layoutInflater)

        setSupportActionBar(binding.specificToolbar)
        val actionBar = supportActionBar
        // 커스텀뷰 허용
        actionBar!!.setDisplayShowCustomEnabled(true)
        // 뒤로가기 버튼 생성
        actionBar!!.setDisplayHomeAsUpEnabled(true)
        // 기본 타이틀 제거
        actionBar!!.setDisplayShowTitleEnabled(false)

        var tabtitle = listOf("메뉴", "정보", "리뷰")
        var fragmentList = listOf(FragmentBaminOne(), FragmentBaminOne(), FragmentBaminOne())

        val adapter = ViewPagerFragmentAdapter(this)
        adapter.fragmentList = fragmentList
        binding.specificViewpager.adapter = adapter
        binding.specificViewpager.orientation = ViewPager2.ORIENTATION_HORIZONTAL
        TabLayoutMediator(binding.specificTabLayout, binding.specificViewpager) {tab, position ->
            tab.text = tabtitle[position]
        }.attach()

        binding.specificToolbarTitle.text = intent.getStringExtra("title")

    }





    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            else -> return true
        }
        return super.onOptionsItemSelected(item)
    }
}