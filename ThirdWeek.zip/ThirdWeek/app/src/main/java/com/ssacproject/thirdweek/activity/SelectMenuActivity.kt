package com.ssacproject.thirdweek.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.ssacproject.thirdweek.FragmentMenu
import com.ssacproject.thirdweek.R
import com.ssacproject.thirdweek.customadapter.SelectFoodItem
import com.ssacproject.thirdweek.customadapter.ViewPagerFragmentAdapter
import com.ssacproject.thirdweek.databinding.ActivitySelectMenuBinding
import java.util.*

class SelectMenuActivity : AppCompatActivity() {
    lateinit var binding: ActivitySelectMenuBinding
    lateinit var tabTitle: List<String>
    lateinit var fragmentList: List<Fragment>

    var selectList = ArrayList<SelectFoodItem>()
    var selectList2 = ArrayList<SelectFoodItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        val actionBar = supportActionBar
        // 커스텀뷰 허용
        actionBar!!.setDisplayShowCustomEnabled(true)
        // 뒤로가기 버튼 생성
        actionBar!!.setDisplayHomeAsUpEnabled(true)
        // 기본 타이틀 제거
        actionBar!!.setDisplayShowTitleEnabled(false)

        selectList.add(SelectFoodItem("육회란 연어다", 5.0, 101, "육연덮밥, 육회초밥",
            40, 55, R.drawable.select_korean_yuk,5000, 3000)
        )
        selectList.add(SelectFoodItem("프리미엄 쫄면삼겹 고돼지은평점", 4.9, 101,
            "고기만(300g), [주문많은]삼겹/목살 1인 도시락", 30, 45,
            R.drawable.select_korean_gopig, 8000, 6000))
        selectList.add(SelectFoodItem("연희옥 연희본점", 4.8, 101, "순대국, 내장탕",
            29, 44, R.drawable.select_korean_yun, 13000, 3500))
        selectList.add(SelectFoodItem("얼음골칡냉면", 4.9, 101, "물냉면(다대기포함), 비빔냉면",
            39, 54, R.drawable.select_korean_nagmyeon, 15000, 5000))
        selectList.add(
            SelectFoodItem("한촌설렁탕 북가좌점", 4.9, 101, "설렁탕, 얼큰설렁탕",
                29, 44, R.drawable.select_korean_hanchon, 5000, 2500)
        )
        selectList.add(SelectFoodItem("곱분이곱창 가재울점", 4.9, 101,
            "숯불직화 모듬 (곱창+막창+오돌뼈), 숯", 40, 57,
            R.drawable.select_korean_gob, 16000, 1000))
        selectList.add(
            SelectFoodItem("호세야 오리 바베큐 은평점", 4.9, 101,
                "국내산오리장작바베큐, 통삼겹장작바베큐", 35, 50,
                R.drawable.select_korean_ho, 17000, 1000)
        )
        selectList.add(SelectFoodItem("독립문1897설렁탕", 4.9, 101, "설렁탕, 불고기",
            50, 65, R.drawable.select_korean_sul, 6000, 6000))



        selectList2.add(SelectFoodItem("육회란 연어다", 5.0, 101, "육연덮밥, 육회초밥",
            40, 55, R.drawable.image_bmart,5000, 3000)
        )
        selectList2.add(SelectFoodItem("프리미엄 쫄면삼겹 고돼지은평점", 4.9, 101,
            "고기만(300g), [주문많은]삼겹/목살 1인 도시락", 30, 45,
            R.drawable.image_shoppinglive, 8000, 6000))
        selectList2.add(SelectFoodItem("연희옥 연희본점", 4.8, 101, "순대국, 내장탕",
            29, 44, R.drawable.image_domestic, 13000, 3500))
        selectList2.add(SelectFoodItem("얼음골칡냉면", 4.9, 101, "물냉면(다대기포함), 비빔냉면",
            39, 54, R.drawable.image_present_big, 15000, 5000))
        selectList2.add(
            SelectFoodItem("한촌설렁탕 북가좌점", 4.9, 101, "설렁탕, 얼큰설렁탕",
                29, 44, R.drawable.image_togo, 5000, 2500)
        )
        selectList2.add(SelectFoodItem("곱분이곱창 가재울점", 4.9, 101,
            "숯불직화 모듬 (곱창+막창+오돌뼈), 숯", 40, 57,
            R.drawable.food_item_galbi, 16000, 1000))
        selectList2.add(
            SelectFoodItem("호세야 오리 바베큐 은평점", 4.9, 101,
                "국내산오리장작바베큐, 통삼겹장작바베큐", 35, 50,
                R.drawable.icon_image, 17000, 1000)
        )
        selectList2.add(SelectFoodItem("독립문1897설렁탕", 4.9, 101, "설렁탕, 불고기",
            50, 65, R.drawable.food_item_juicy, 6000, 6000))



        val tabTitle1 = listOf("한식", "분식", "카페·디저트", "돈까스·회·일식", "치킨", "피자", "아시안·양식",
            "중국집", "족발·보쌈", "야식", "찜·탕", "도시락", "패스트푸드")
        // 각 프래그먼트 별로 필요한 데이터를 다르게 하기.
        val fragmentList1 = listOf( FragmentMenu(selectList), FragmentMenu(selectList2),
            FragmentMenu(selectList), FragmentMenu(selectList2), FragmentMenu(selectList),
            FragmentMenu(selectList2), FragmentMenu(selectList), FragmentMenu(selectList),
            FragmentMenu(selectList), FragmentMenu(selectList), FragmentMenu(selectList),
            FragmentMenu(selectList), FragmentMenu(selectList))

        val tabTitle2 = listOf("돈까스·회·일식", "중식", "치킨", "백반·죽·국수", "카페·디저트", "분식",
            "찜·탕·찌게", "피자", "양식", "고기·구이", "족발·보쌈", "아시안", "버거")
        val fragmentList2 = listOf(
            FragmentMenu(selectList), FragmentMenu(selectList2),
            FragmentMenu(selectList), FragmentMenu(selectList2), FragmentMenu(selectList),
            FragmentMenu(selectList2), FragmentMenu(selectList), FragmentMenu(selectList),
            FragmentMenu(selectList), FragmentMenu(selectList), FragmentMenu(selectList),
            FragmentMenu(selectList), FragmentMenu(selectList)
        )



        // 보내진 곳에 따라서 리스트 다르게 설정하기
        val what = intent.getIntExtra("what", 0)
        when(what) {
            0 -> {tabTitle = tabTitle1; fragmentList = fragmentList1}
            else -> {tabTitle = tabTitle2; fragmentList = fragmentList2}
        }
        val adapter = ViewPagerFragmentAdapter(this)
        adapter.fragmentList = fragmentList
        binding.viewpager.adapter = adapter
        binding.viewpager.orientation = ViewPager2.ORIENTATION_HORIZONTAL
        TabLayoutMediator(binding.tabLayout, binding.viewpager) {tab, position ->
            tab.text = tabTitle[position]
        }.attach()
        binding.tabLayout.addOnTabSelectedListener(object: TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                val pos = tab?.position
                binding.toolbarTitle.text = tabTitle[pos!!]
                // 이 부분에서 해당 포지션에 해당하는 프래그먼트의 데이터 유형을 설정한다.
                val frag = fragmentList[pos]
                val datatype = pos

            }
            override fun onTabReselected(tab: TabLayout.Tab?) {
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
            }
        })
        val pos = intent.getIntExtra("position", 0)
        binding.viewpager.setCurrentItem(pos, false)
        binding.toolbarTitle.text = tabTitle[pos]

        val chipReset = binding.chipGroup.findViewById<Chip>(R.id.chipReset)
        chipReset.setOnClickListener {
            chipReset.visibility = View.GONE
        }

        binding.chipGroup.setOnCheckedChangeListener(object: ChipGroup.OnCheckedChangeListener {
            override fun onCheckedChanged(group: ChipGroup?, checkedId: Int) {
                if (checkedId != R.id.chipReset) {
                    group?.findViewById<Chip>(R.id.chipReset)?.visibility = View.VISIBLE
                }

            }
        })

        val chipTipLowest: Chip = binding.chipGroup.findViewById(R.id.chipTipLowest)
        chipTipLowest.setOnClickListener {
            val tmpfrag = fragmentList[binding.viewpager.currentItem] as FragmentMenu
            tmpfrag.changeDataSort("chipTipLowest")
        }

        val chipTopRatings: Chip = binding.chipGroup.findViewById(R.id.chipTopRatings)
        chipTopRatings.setOnClickListener {
            val tmpfrag = fragmentList[binding.viewpager.currentItem] as FragmentMenu
            tmpfrag.changeDataSort("chipTopRatings")
        }

        val chipFastest: Chip = binding.chipGroup.findViewById(R.id.chipFastest)
        chipFastest.setOnClickListener {
            val tmpfrag = fragmentList[binding.viewpager.currentItem] as FragmentMenu
            tmpfrag.changeDataSort("chipFastest")
        }

        val chipNormal: Chip = binding.chipGroup.findViewById(R.id.chipNormal)
        chipNormal.setOnCloseIconClickListener {
            val tmpfrag = fragmentList[binding.viewpager.currentItem] as FragmentMenu
            tmpfrag.changeDataSort("chipNormal")
        }

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            else -> return true
        }
        return super.onOptionsItemSelected(item)
    }




}