package com.ssacproject.thirdweek.food_fragment_real

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager2.widget.ViewPager2
import com.ssacproject.thirdweek.*
import com.ssacproject.thirdweek.activity.SelectMenuActivity
import com.ssacproject.thirdweek.customadapter.CustomMainMenuAdAdapter
import com.ssacproject.thirdweek.customadapter.CustomTodaySaleAdapter
import com.ssacproject.thirdweek.customadapter.FoodItemAdapter
import com.ssacproject.thirdweek.customadapter.ItemTodaySale
import com.ssacproject.thirdweek.customview.CustomMainMenuAd
import com.ssacproject.thirdweek.customview.CustomMainRecyclerView
import com.ssacproject.thirdweek.customview.GridItem

class FragmentDelivery : Fragment() {

    lateinit var customMainMenuAdDelivery: CustomMainMenuAd
    lateinit var custom1: CustomMainRecyclerView
    lateinit var custom2: CustomMainRecyclerView
    lateinit var handler: Handler
    lateinit var handRun: Runnable

    val imageList = listOf(
        R.drawable.ad1, R.drawable.ad2, R.drawable.ad3, R.drawable.ad4, R.drawable.ad5, R.drawable.ad6)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_delivery, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        customMainMenuAdDelivery = view.findViewById(R.id.customMainMenuAdDelivery)
        val customAdAdapter = CustomMainMenuAdAdapter()
        customAdAdapter.imageList = imageList
        customAdAdapter.setShowAll = true
        val len = customAdAdapter.imageList.size
        customMainMenuAdDelivery.tot.text = "${len}"
        if (len > 0) {
            customMainMenuAdDelivery.cur.text = "${1}"
        } else {
            customMainMenuAdDelivery.cur.text = "${0}"
        }
        customMainMenuAdDelivery.viewpager_ad.adapter = customAdAdapter
        // 핸들러 설정해서 자동으로 스와이프
        handler = Handler()
        handRun = Runnable {
            customMainMenuAdDelivery.viewpager_ad.currentItem = customMainMenuAdDelivery.viewpager_ad.currentItem + 1
        }
        // 뷰페이저 스와이프할 때마다 숫자 바꿔주기
        customMainMenuAdDelivery.viewpager_ad.registerOnPageChangeCallback(object: ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                handler.removeCallbacks(handRun)
                handler.postDelayed(handRun, 3000)
                customMainMenuAdDelivery.tot.text = "${len}"
                val now = position%len + 1
                customMainMenuAdDelivery.cur.text ="${now}"
            }
        })

        custom1 = view.findViewById(R.id.custom1)
        val layoutManager1 = LinearLayoutManager(context)
        layoutManager1.orientation = LinearLayoutManager.HORIZONTAL
        custom1.recycler.layoutManager = layoutManager1
        val customAdapter1 = CustomTodaySaleAdapter(requireContext())
        val data1 = ArrayList<ItemTodaySale>()
        data1.add(ItemTodaySale(R.drawable.logo_dominos, "도미노피자 전 메뉴", "7천원 할인",
            "기간:9/13~9/23", "", R.drawable.today_sale_food_domino, R.color.mint))
        data1.add(ItemTodaySale(R.drawable.logo_sunsoo, "순수치킨 전 메뉴", "5천원 할인",
            "9월 매주 목,토", "배달 주문시에만 가능합니다.",
                    R.drawable.today_sale_food_sunsoo, R.color.ashgray))
        data1.add(ItemTodaySale(R.drawable.logo_ttu, "신메뉴 2종 출시!", "4천원 할인",
            "세계 3대 진미 트러플크림찜닭!", "극강의 매운 맛 불마왕불닭!", R.drawable.today_sale_food_ttu, R.color.basy))
        data1.add(ItemTodaySale(R.drawable.logo_ashley, "배달·포장 주문시", "5천원 할인",
            "스테이크부터 파스타,샐러드까지!", "할인혜택으로 애슐리를 즐겨보세요!", R.drawable.today_sale_food_ashley, R.color.mint))
        data1.add(
            ItemTodaySale(R.drawable.logo_boor, "색다른, 부어치킨", "7천원 할인",
        "9월 18일~9월 22일(추석 연휴)", "7천원 할인", R.drawable.today_sale_food_boor,
                R.color.littlepurple)
        )
        data1.add(
            ItemTodaySale(R.drawable.logo_gob, "곱창떡볶이 평판1등", "4천원 할인",
        "꾸덕꾸덕 로제와 쫄깃한 곱창-!", "소곱창 로제떡볶이-!", R.drawable.today_sale_food_gob,
                R.color.basy)
        )
        data1.add(
            ItemTodaySale(R.drawable.logo_catnip, "깻잎 추석세트!", "5천원 할인",
        "9월 13일 ~ 22일 (추석세트 5종 할인)", "추석은 깻잎치킨이 챙겨 드릴게요",
                    R.drawable.today_sale_food_catnip, R.color.mint)
        )
        data1.add(ItemTodaySale(R.drawable.logo_sam, "삼첩분식 전 메뉴", "4천원 할인",
        "9월 6일 ~ 9월 19일 (14일간)", "맵싸한 마라로 제 떡볶이부터 튀김, 막창까지!",
        R.drawable.today_sale_food_sam, R.color.basy))
        data1.add(
            ItemTodaySale(R.drawable.logo_pas, "파스쿠찌", "5천원 할인",
        "배달 시 5,000원 할인", "포장 주문 시 3,000원 할인",
                R.drawable.today_sale_food_pas, R.color.ashgray)
        )

        customAdapter1.todaySaleList = data1
        custom1.recycler.adapter = customAdapter1


        custom2 = view.findViewById(R.id.custom2)
        val layoutManager2 = LinearLayoutManager(context)
        layoutManager2.orientation = LinearLayoutManager.VERTICAL
        custom2.recycler.layoutManager = layoutManager2
        val foodAdapter2 = FoodItemAdapter()
        val data2 = ArrayList<Food>()
        data2.add(Food("원할머니보쌈족발 녹번점", "16~31분", "족발·보쌈, 모둠보쌈, 보족원쌈",
                        R.drawable.food_item_one))
        data2.add(Food("원할머니명품도시락 녹번점", "21~36분", "도시락, 보쌈도시락, 제육도시락",
                        R.drawable.food_item_bossam))
        data2.add(Food("샐러디 응암점", "18~33분", "패스트푸드, 탄단지 샐러드, 칠리베이컨 웜볼",
                        R.drawable.food_item_salad))
        data2.add(Food("블리담담 샐러드&요거트", "18~33분",
                    "카페·디저트, 닭가슴살 샐러드, 쉬림프 샐러드", R.drawable.food_item_vegetable))
        data2.add(Food("돈갓스대장 은평점", "29~44분", "돈까스·회·일식, 통등심돈까스, 돈까스 쌈밥",
                        R.drawable.food_item_katsu))
        data2.add(Food("쥬씨 홍제점", "40~55분", "수박, 수박팩", R.drawable.food_item_juicy))
        data2.add(Food("파스따블 떡볶이 독바위본점", "38~53분",
                        "아시안·양식, 알리오 올리오, 베이컨 로제 파스타", R.drawable.food_item_pasta))
        data2.add(Food("맵당 매운갈비찜 신촌본점", "50~65분", "매운갈비찜, 로제 눈꽃치즈 갈비찜",
                            R.drawable.food_item_galbi))
        data2.add(Food("북촌손만두 응암점", "30~40분", "북촌피냉면, 튀김만두",
                            R.drawable.food_item_dumpling))
        data2.add(Food("이것이 쿠키다 홍제점", "20~30분", "반죽쿠키, 초콜릿칩 쿠키",
                            R.drawable.food_item_cookie))
        data2.add(Food("홍콩반점 홍제점", "40~45분", "짜장면, 짬뽕, 탕수육",
                        R.drawable.food_item_jja))
        foodAdapter2.foodList = data2
        custom2.recycler.adapter = foodAdapter2

        var food_grid_layout = view.findViewById<GridLayout>(R.id.food_grid_layout)
//        var grid_korean = food_grid_layout.findViewById<GridItem>(R.id.grid_korean)
//        grid_korean.setOnClickListener {
//            val intent = Intent(context, SelectMenuActivity::class.java)
//            intent.putExtra("position", 0)
//            startActivity(intent)
//        }
        for (i in 1 until food_grid_layout.childCount-6) {
            var grid = food_grid_layout.getChildAt(i)
            grid.setOnClickListener {
                val intent = Intent(context, SelectMenuActivity::class.java)
                intent.putExtra("position", i-1)
                intent.putExtra("what", 0)
                startActivity(intent)
            }
        }

    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(handRun)
    }

    override fun onResume() {
        super.onResume()
        handler.postDelayed(handRun, 3000)
    }

}