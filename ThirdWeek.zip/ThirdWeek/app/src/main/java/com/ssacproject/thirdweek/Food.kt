package com.ssacproject.thirdweek

data class Food(val title: String, val time: String, val menu: String, val image: Int)