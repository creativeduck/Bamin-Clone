package com.ssacproject.thirdweek

import android.view.View

interface OnItemClickListener {
    fun onItemClicked(view: View, pos: Int)
}

interface OnItemLongClickListener {
    fun onItemLongClicked(view: View, pos: Int)
}

interface OnItemClickWithNoPosListener {
    fun onItemClicked(view: View)
}